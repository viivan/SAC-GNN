"""
某些数据增强方法中使用，计算两者之间的相关程度
两种不同的相似度计算
train_based 利用训练中的embedding来计算sim（要不要直接写到训练过程中呢）
info_based 利用服务原有的信息进行sim的计算
两者结合 SWCS
"""

import torch
import math
import torch.nn.functional as F
import numpy as np
import data_read as dr
import util
import augmentation as aug
import parser_init
import time

t_args = parser_init.init_parser()


# 余弦相似度计算
def cos_sim(vec1, vec2):
    v_sum = 0
    for i in range(len(vec1)):
        v_sum = v_sum + vec1[i] * vec2[i]
    vec1_len = math.sqrt(sum([i * i for i in vec1]))
    vec2_len = math.sqrt(sum([i * i for i in vec2]))
    return v_sum / (vec1_len * vec2_len)


# 利用现有信息进行计算
# TODO: api应当都为已知信息，需要增加api tag为基础的sim计算
class InfoSim:

    # 类中用来存放几种相似度dict，对应的最大和最小值，以及利用最大最小值归一化的相似度结果
    def __init__(self):
        self.description_sim_dict = None
        self.description_sim_max_min = None  # list: [max_value, min_value]
        self.normalized_description_sim_dict = None
        self.item_cf_iuf_sim_dict = None
        self.item_cf_iuf_sim_max_min = None  # list: [max_value, min_value]
        self.normalized_item_cf_iuf_sim_dict = None
        self.whole_normalized_sim_dict = None

    # 服务描述相似度计算过程
    # 参数为服务index和整体的vec信息
    # 使用cos相似度计算好了
    # 返回值为相似度dict，key为当前service index，value也是dict，包括 对象index:对应sim
    def cal_description_similarity(self, service_index, service_description_vec):
        s = dict()
        for s_index in service_index:
            s.setdefault(s_index, {})
            for p_s_index in service_index:

                print(s_index, p_s_index)

                if s_index == p_s_index:
                    continue
                else:
                    s[s_index].setdefault(p_s_index, 0)
                    s_vec = service_description_vec[s_index]
                    p_vec = service_description_vec[p_s_index]
                    # 计算相似度非常耗时，不过只要计算一次其实还行吧
                    # TODO: 哎还是写一个持久化吧
                    sim = cos_sim(s_vec, p_vec)
                    s[s_index][p_s_index] = sim
        self.description_sim_dict = s

    # 从持久化文件中读取相似度信息
    def cal_description_sim_from_file(self, file_name):
        s = dr.read_service_sim_dict(file_name)
        self.description_sim_dict = s

    # 计算文档相似度的最大最小值
    def cal_description_max_min(self):
        des_max = -10000
        des_min = 10000
        for service_now, current_sim in self.description_sim_dict.items():
            for c_s, value in current_sim.items():
                des_max = max(value, des_max)
                des_min = min(value, des_min)
        self.description_sim_max_min = [des_max, des_min]

    # 计算归一化的文档相似度
    def cal_normalized_description_similarity(self):
        s = dict()
        for service_now, current_sim in self.description_sim_dict.items():
            s.setdefault(service_now, {})
            for c_s, value in current_sim.items():
                s[service_now].setdefault(c_s, 0)
                if self.description_sim_max_min[0] == self.description_sim_max_min[1]:
                    s[service_now][c_s] = 1
                    continue
                s[service_now][c_s] = (value - self.description_sim_max_min[1]) / \
                                      (self.description_sim_max_min[0] - self.description_sim_max_min[1])
        self.normalized_description_sim_dict = s

    # itemCF_IUF计算，iuf使较长的序列对相似度的有效性更强
    # 常用的基于频率的相似度计算方法
    # 参数为list形态的序列，考虑转成dict进行计算
    # 返回值为相似度dict，key为当前service index，value也是dict，包括 对象index:对应sim
    def cal_item_cf_iuf_similarity(self, sequence_list):
        # 关键是计算service出现的次数和对应service一起出现的次数
        appear_num = dict()
        current_num = dict()
        for seq in sequence_list:
            for s1 in seq:
                # 计算出现次数
                appear_num.setdefault(s1, 0)
                appear_num[s1] += 1
                current_num.setdefault(s1, {})
                # 计算共同出现次数+iuf参数
                for s2 in seq:
                    if s1 == s2:
                        continue
                    current_num[s1].setdefault(s2, 0)
                    current_num[s1][s2] += 1 / math.log(1.0 + len(seq))
        # 计算结果
        s = dict()
        for service_now, current_s_num in current_num.items():
            # 计算每个service之间的相似度
            s.setdefault(service_now, {})
            for current_service, value in current_s_num.items():
                s[service_now].setdefault(current_service, 0)
                s[service_now][current_service] = value / math.sqrt(appear_num[service_now] * appear_num[current_service])
        self.item_cf_iuf_sim_dict = s

    # 计算itemCF-iuf的结果的最大最小值
    def cal_item_cf_iuf_max_min(self):
        des_max = -10000
        des_min = 10000
        for service_now, current_sim in self.item_cf_iuf_sim_dict.items():
            for c_s, value in current_sim.items():
                des_max = max(value, des_max)
                des_min = min(value, des_min)
        self.item_cf_iuf_sim_max_min = [des_max, des_min]

    # 计算itemCF-iuf的归一化版本
    def cal_normalized_item_cf_iuf_similarity(self):
        s = dict()
        for service_now, current_sim in self.item_cf_iuf_sim_dict.items():
            s.setdefault(service_now, {})
            for c_s, value in current_sim.items():
                s[service_now].setdefault(c_s, 0)
                if self.item_cf_iuf_sim_max_min[0] == self.item_cf_iuf_sim_max_min[1]:
                    s[service_now][c_s] = 1
                    continue
                s[service_now][c_s] = (value - self.item_cf_iuf_sim_max_min[1]) / \
                                      (self.item_cf_iuf_sim_max_min[0] - self.item_cf_iuf_sim_max_min[1])
        self.normalized_item_cf_iuf_sim_dict = s

    # 计算最终的info效果
    # 暂时先用这两个
    # 以description为底，这样保证每个之间都有值
    def cal_whole_normalized_sim(self):
        s = dict()
        dec_dict = self.normalized_description_sim_dict
        cf_dict = self.normalized_item_cf_iuf_sim_dict
        for service, current_service in dec_dict.items():
            s.setdefault(service, {})
            for c_s, value in dec_dict[service].items():
                s[service].setdefault(c_s, value)
                if service in cf_dict.keys() and c_s in cf_dict[service].keys():
                    s[service][c_s] = 0.5 * dec_dict[service][c_s] + 0.5 * cf_dict[service][c_s]
        self.whole_normalized_sim_dict = s


# 利用训练中embedding计算相似度
class TrainSim:

    # 初始化先
    def __init__(self):
        self.train_sim_dict = None
        self.train_sim_max_min = None
        self.normalized_train_sim_dict = None

    # 计算相关性得分先
    # 要注意的是，输入的参数service_index和service_tensor_vec之间是顺序对应的
    def cal_train_similarity(self, service_index, service_tensor_vec):
        # 生成service_now和其余所有service对应的list
        service_pair_left = []
        service_pair_right = []
        index_dict = {}
        t = 0
        for s1 in service_index:
            index_dict[s1] = t
            t += 1
            for s2 in service_index:
                if s1 == s2:
                    continue
                service_pair_left.append(s1)
                service_pair_right.append(s2)
        service_vec_index_left = []
        service_vec_index_right = []
        for s in service_pair_left:
            service_vec_index_left.append(index_dict[s])
        for s in service_pair_right:
            service_vec_index_right.append(index_dict[s])
        service_tensor_left = service_tensor_vec[service_vec_index_left]
        service_tensor_right = service_tensor_vec[service_vec_index_right]
        service_tensor_sim = F.cosine_similarity(service_tensor_left, service_tensor_right, dim=1)
        # 转成numpy不然会有tensor的复制非常慢
        service_tensor_sim = torch.Tensor.cpu(service_tensor_sim)
        service_tensor_sim = service_tensor_sim.detach()
        service_tensor_sim = service_tensor_sim.numpy()
        # 转为dict方便计算
        s = dict()
        t5 = time.time()
        max_sim = - 100
        min_sim = 100
        for i in range(len(service_pair_left)):
            service_left = service_pair_left[i]
            service_right = service_pair_right[i]
            s.setdefault(service_left, {})
            # s[service_left].setdefault(service_right, 0)
            # 转为float防止np数据处理占用时间
            s[service_left][service_right] = float(service_tensor_sim[i])
            # max_sim = max(s[service_left][service_right], max_sim)
            # min_sim = min(s[service_left][service_right], min_sim)

        t6 = time.time()
        # print("input sim", round((t6 - t5), 1))
        self.train_sim_dict = s

    # 计算train sim的最大与最小值
    def cal_train_sim_max_min(self):
        max_sim = - 100
        min_sim = 100
        t5 = time.time()
        for service_now, current_service_num in self.train_sim_dict.items():
            for c_s, value in current_service_num.items():
                max_sim = max(value, max_sim)
                min_sim = min(value, min_sim)
        self.train_sim_max_min = [max_sim, min_sim]
        t6 = time.time()
        # print("max min sim", round((t6 - t5), 1))

    # 计算归一化的train sim
    def cal_normalized_train_sim_dict(self):
        s = dict()
        for service_now, current_sim in self.train_sim_dict.items():
            s.setdefault(service_now, {})
            for c_s, value in current_sim.items():
                s[service_now].setdefault(c_s, 0)
                if self.train_sim_max_min[0] == self.train_sim_max_min[1]:
                    s[service_now][c_s] = 1
                    continue
                s[service_now][c_s] = (value - self.train_sim_max_min[1]) / \
                                      (self.train_sim_max_min[0] - self.train_sim_max_min[1])
        self.normalized_train_sim_dict = s


# 整体的sim计算类
# 给一个epoch limit阈值来决定相似度类的方法调用
# service whole combined similarity 起名好土，先这样吧
class SWCS:

    # 初始化把sim类拿进来
    def __init__(self, info_sim, train_sim, epoch_threshold=100):
        self.info_sim = info_sim
        self.train_sim = train_sim
        self.whole_sim_now_dict = None
        self.epoch_threshold = epoch_threshold
        self.sorted_service_dict = None

    # 根据threshold进行当前的sim的更新
    # 后面两个参数用来对train_sim进行计算更新
    # 注意为了计算完整情况，需要将对应的所有sequence进行计算
    def update_whole_sim(self, epoch, service_index, service_dec_vec, service_sequence, service_tensor_vec):
        if epoch <= self.epoch_threshold:
            if self.whole_sim_now_dict is None:
                # 初始化info_sim，免得要在外面进行初始化
                self.info_sim.cal_description_similarity(service_index, service_dec_vec)
                self.info_sim.cal_description_max_min()
                self.info_sim.cal_normalized_description_similarity()
                self.info_sim.cal_item_cf_iuf_similarity(service_sequence)
                self.info_sim.cal_item_cf_iuf_max_min()
                self.info_sim.cal_normalized_item_cf_iuf_similarity()
                self.info_sim.cal_whole_normalized_sim()
                self.whole_sim_now_dict = self.info_sim.whole_normalized_sim_dict
            else:
                # 并不是第一次的情况，直接跳过就好了
                return
        else:
            # 两者混用的情况，首先对train进行更新并进行归一化处理
            t1 = time.time()
            self.train_sim.cal_train_similarity(service_index, service_tensor_vec)
            self.train_sim.cal_train_sim_max_min()
            self.train_sim.cal_normalized_train_sim_dict()
            # 更新后将两者进行结合
            info_dict = self.info_sim.whole_normalized_sim_dict
            train_dict = self.train_sim.normalized_train_sim_dict
            # 因为有des和embed兜底，所以每个组合都能拿到，放心一次即可
            s = dict()
            for service, current_service in info_dict.items():
                s.setdefault(service, {})
                for c_s, value in info_dict[service].items():
                    s[service].setdefault(c_s, value)
                    if c_s in train_dict[service].keys():
                        s[service][c_s] = max(info_dict[service][c_s], train_dict[service][c_s])
            t2 = time.time()
            print(round((t2 - t1), 1))
            self.whole_sim_now_dict = s

    # 使用sim file进行相似度的初始化
    def update_whole_sim_using_save(self, epoch, service_index, service_dec_vec, service_sequence, service_tensor_vec, service_sim_dic_file_name):
        if epoch <= self.epoch_threshold:
            if self.whole_sim_now_dict is None:
                # 初始化info_sim，免得要在外面进行初始化
                self.info_sim.cal_description_sim_from_file(service_sim_dic_file_name)
                self.info_sim.cal_description_max_min()
                self.info_sim.cal_normalized_description_similarity()
                self.info_sim.cal_item_cf_iuf_similarity(service_sequence)
                self.info_sim.cal_item_cf_iuf_max_min()
                self.info_sim.cal_normalized_item_cf_iuf_similarity()
                self.info_sim.cal_whole_normalized_sim()
                self.whole_sim_now_dict = self.info_sim.whole_normalized_sim_dict
            else:
                # 并不是第一次的情况，直接跳过就好了
                return
        else:
            # 两者混用的情况，首先对train进行更新并进行归一化处理
            # print("train sim calculating")
            t1 = time.time()
            self.train_sim.cal_train_similarity(service_index, service_tensor_vec)
            self.train_sim.cal_train_sim_max_min()
            self.train_sim.cal_normalized_train_sim_dict()
            t2 = time.time()
            # print("train sim", round((t2 - t1), 1))

            # 更新后将两者进行结合
            info_dict = self.info_sim.whole_normalized_sim_dict
            train_dict = self.train_sim.normalized_train_sim_dict
            # 因为有des和embed兜底，所以每个组合都能拿到，放心一次即可
            # print("whole sim merging")
            s = dict()
            for service, current_service in info_dict.items():
                s.setdefault(service, {})
                for c_s, value in info_dict[service].items():
                    s[service].setdefault(c_s, value)
                    if service in train_dict.keys() and c_s in train_dict[service].keys():
                        s[service][c_s] = max(info_dict[service][c_s], train_dict[service][c_s])
            self.whole_sim_now_dict = s
            t3 = time.time()
            # print("combine sim", round((t3 - t2), 1))

    # 将dict进行排序处理
    def sort_sim_dict(self):
        # 对已经完成的选手进行排序处理
        # 如果排序太浪费时间就直接找最大值好了
        # sort会对原数据进行修改，sorted不会
        s = dict()
        for service, current_service in self.whole_sim_now_dict.items():
            # 根据value排序
            s[service] = sorted(current_service.items(), key=lambda x: x[1], reverse=True)
        self.sorted_service_dict = s

    # find max
    def find_max(self):
        s = dict()
        for service, current_service in self.whole_sim_now_dict.items():
            max_index = 0
            max_value = -1
            for key, value in current_service.items():
                if value > max_value:
                    max_index = key
                    max_value = value
            s[service] = max_index


if __name__ == "__main__":
    a = torch.tensor([[1, 2], [3, 4], [5, 6], [7, 8]], dtype=torch.float)
    d_vec = np.array([[1, 2], [3, 4], [5, 6], [7, 8]], dtype=np.float)
    c_list = [[0, 1], [0, 1, 2], [0, 2], [0, 1], [2, 1], [0, 1, 2]]

    t_service_index = [0, 1, 2]

    train = TrainSim()
    info = InfoSim()

    """
    print("###############train")
    train = TrainSim()
    # train loss测试
    train.cal_train_similarity(t_service_index, a)
    print(train.train_sim_dict)
    print(cos_sim(a[0], a[1]))
    train.cal_train_sim_max_min()
    print(train.train_sim_max_min)
    train.cal_normalized_train_sim_dict()
    print(train.normalized_train_sim_dict)

    print("###############info")
    info = InfoSim()
    # des loss 测试
    print("###############desc")
    info.cal_description_similarity(t_service_index, d_vec)
    print(info.description_sim_dict)
    info.cal_description_max_min()
    print(info.description_sim_max_min)
    info.cal_normalized_description_similarity()
    print(info.normalized_description_sim_dict)

    print("###############itemcf")
    info.cal_item_cf_iuf_similarity(c_list)
    print(info.item_cf_iuf_sim_dict)
    info.cal_item_cf_iuf_max_min()
    print(info.item_cf_iuf_sim_max_min)
    info.cal_normalized_item_cf_iuf_similarity()
    print(info.normalized_item_cf_iuf_sim_dict)

    print("###############combine")
    info.cal_whole_normalized_sim()
    print(info.whole_normalized_sim_dict)
    """

    """
    print("###############swcs")
    sec = SWCS(info_sim=info, train_sim=train, epoch_threshold=1)
    sec.update_whole_sim(0, t_service_index, d_vec, c_list, a)
    print(sec.whole_sim_now_dict)
    sec.update_whole_sim(3, t_service_index, d_vec, c_list, a)
    print(sec.whole_sim_now_dict)

    print("###############sort")
    sec.sort_sim_dict()
    print(sec.sorted_service_dict)
    for key in sec.sorted_service_dict.keys():
        temple = util.get_top_sim_service(sec.sorted_service_dict, key, 1)
        print(temple)

    print("###############augAdaptor")
    aug_adaptor = aug.AugmentationAdaptor(sec, t_args)
    aug_adaptor.append_aug_method("c,m,im,ch")
    aug_adaptor.create_aug_index_list()
    print(aug_adaptor.augmentation_methods)
    print(aug_adaptor.aug_index_list)

    print("###############aug")
    for seq in c_list:
        new_seq = aug_adaptor(seq)
        print("former:{}, now:{}".format(seq, new_seq))
    """





