"""
train整体流程
包括cl方法的组装，data计算获取和model的组装
"""
import cl_loss
import model_test
import torch
import torch.nn as nn


class CLTrain:

    # 整合完成的cl_sac_gnn模型
    # 利用结果计算两段loss
    # cl不需要ground-truth，sl loss需要把ground也加进来
    def __init__(self, model, m_a_id, cl_loss_func, args):
        self.args = args
        self.m_a_id = m_a_id
        self.model = model
        self.cl_loss_func = cl_loss_func

    # 完全sample尝试
    # (或者单个正例多个负例)
    # mashup_index为对应sample的m序号，mashup_embeddings为按mashup_index顺序排的embedding，别用错了
    # 从字典型的pos_dic和neg_dic中取出多个正负例
    @staticmethod
    def multi_bpr_loss(mashup_index, mashup_embeddings, api_embeddings, pos_dic, neg_dic):
        loss = None
        for i in range(len(mashup_index)):
            s_mashup_embedding = mashup_embeddings[i]
            s_mashup_index = mashup_index[i]
            s_sample_pos_list = pos_dic[s_mashup_index]
            s_sample_neg_list = neg_dic[s_mashup_index]

            # [pos_sample_num, embed_dim] -> [pos_sample_num * neg_sample_num, embed_dim]
            # [0, 1...] - > [0,0,1,1...]
            # [neg_sample_num, embed_dim] -> [neg_sample_num * neg_sample_num, embed_dim]
            # [0, 1...] - > [0,1,...,0,1...]
            p_n_index = []
            for p in s_sample_pos_list:
                p_n_index.extend([p] * len(s_sample_neg_list))
            n_p_index = s_sample_neg_list * len(s_sample_pos_list)
            pos_embeddings = api_embeddings[p_n_index]
            neg_embeddings = api_embeddings[n_p_index]

            m_pos_neg_e = s_mashup_embedding.repeat(len(s_sample_pos_list) * len(s_sample_neg_list), 1)
            pos_scores = torch.sum(torch.mul(m_pos_neg_e, pos_embeddings), dim=1)  # [p*n, 1]
            neg_scores = torch.sum(torch.mul(m_pos_neg_e, neg_embeddings), dim=1)  # [p*n, 1]
            maxi = nn.LogSigmoid()(pos_scores - neg_scores)
            mf_loss = -1 * torch.mean(maxi)
            if loss is None:
                loss = mf_loss
            else:
                loss = mf_loss + loss
        return loss

    # 计算sl model的loss结果
    def sl_loss_train(self, mashup_list, api_list, mashup_embeddings, api_embeddings):
        # 计算bpr需要的正负例
        pos_sample_num = self.args.pos_sample_num
        neg_sample_num = self.args.neg_sample_num
        m_pos_dic, m_neg_dic = model_test.sample_multi_pos_neg_api(mashup_list, api_list, pos_sample_num, neg_sample_num, self.m_a_id)
        loss = 0
        # 多正负例loss计算
        if self.args.loss_func == 'sample_bpr':
            loss = self.multi_bpr_loss(mashup_list, mashup_embeddings, api_embeddings, m_pos_dic, m_neg_dic)
        return loss

    # 计算cl loss信息
    def cl_loss_train(self, api_aug_list, mashup_aug_list):
        # pair，list length为2，一一对应
        api_loss = self.cl_loss_func(api_aug_list[0], api_aug_list[1])
        mashup_loss = self.cl_loss_func(mashup_aug_list[0], mashup_aug_list[1])
        return api_loss, mashup_loss

    # train一轮，包括两个loss的计算和bp过程
    # 记得把loss返回
    # api_seq_list是train中的api_id，对应的mashup序列中的mashup_index都在train mashup中
    def train_once(self, mashup_list, api_list, api_seq_list, mashup_dec_vec, api_dec_vec, mashup_des_sim_file_name, api_des_sim_file_name, epoch, optimizer, scheduler=None):
        api_aug_list, mashup_aug_list, mashup_embeddings, api_embeddings = self.model(mashup_list, api_list, api_seq_list, mashup_dec_vec, api_dec_vec, mashup_des_sim_file_name, api_des_sim_file_name, epoch)
        sl_loss = self.sl_loss_train(mashup_list, api_list, mashup_embeddings, api_embeddings)
        cl_api_loss, cl_mashup_loss = self.cl_loss_train(api_aug_list, mashup_aug_list)

        whole_loss = sl_loss + self.args.cl_loss_rate * (cl_api_loss + cl_mashup_loss)

        optimizer.zero_grad()
        whole_loss.backward()
        optimizer.step()
        if scheduler is not None:
            print("学习率：%f" % (optimizer.param_groups[0]['lr']))
            scheduler.step()

        return whole_loss, sl_loss, cl_mashup_loss, cl_api_loss
    