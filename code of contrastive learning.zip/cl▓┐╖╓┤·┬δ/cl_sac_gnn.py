"""
把sac-gnn模型整合一下
写成类似Encoder的模式好了
把loss func的计算也写到这里好了
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import augmentation
import MAIGNet_sigma
import random
import cl_loss
import model_test
import parser_init
import data_read as dr
import time


# 整合模型，包括对MAIG的选手进行处理
# 感觉不用继承model，直接返回增强后的embedding表示即可
class CLSacGnn:

    # 初始化，参数为主要的sl model；增强策略类；原始序列
    # 因为要计算mashup和api两者的loss，需要两个
    # 类的初始化和组装写在train中好了
    def __init__(self, main_model, mashup_aug_adaptor, api_aug_adaptor, mashup_former_sequence, api_former_sequence, args):
        self.model = main_model
        self.mashup_aug_adaptor = mashup_aug_adaptor
        self.api_aug_adaptor = api_aug_adaptor
        self.mashup_former_sequence = mashup_former_sequence
        self.api_former_sequence = api_former_sequence
        self.args = args

    # 主要计算分为几步
    # 首先model先将index中的全部计算完成，获取两种output和index_list对应
    # 原序列获取，增强处理，返回mean-pooling结果
    # 返回值，api-pair，mashup-pair，mashup_embedding，api_embedding
    # mashup_dec_vec, api_dec_vec用来初始化mashup和api的info sim
    # 需要注意的是api_seq_list和api_list并不相同，因为train中并不能得到所有的api信息
    def __call__(self, mashup_list, api_list, api_seq_list, mashup_dec_vec, api_dec_vec, mashup_des_sim_file_name, api_des_sim_file_name, epoch):
        # 切换train
        self.model.train()
        # drop增加泛化能力，其实还是有效果的，开着吧
        self.model.if_graph_drop = True
        # 注意这边的embedding顺序适合list中的值对应的
        mashup_embeddings, api_embeddings = self.model(mashup_list, api_list)

        # 计算每个service序号对应的embedding序号的dict
        mashup_embed_index_dict = dict()
        api_embed_index_dict = dict()
        for i in range(len(mashup_list)):
            mashup_embed_index_dict[mashup_list[i]] = i
        for i in range(len(api_list)):
            api_embed_index_dict[api_list[i]] = i

        # 增强生成新的序列，sample一定量的sequence先
        # 对api进行sample，注意sequence是包含所有的数据而不是只有list中的序号，所以要再把序号存起来
        api_sample_index_list = random.sample([x for x in range(len(api_seq_list))], k=self.args.api_seq_sample_num)
        mashup_sample_index_list = random.sample([x for x in range(len(mashup_list))], k=self.args.mashup_seq_sample_num)
        api_aug_list = [api_seq_list[i] for i in api_sample_index_list]  # 增强所需要使用的api序号列表
        mashup_aug_list = [mashup_list[i] for i in mashup_sample_index_list]  # 增强所需要使用的mashup序号列表

        # 需要进行sim的update
        # api的sequence对应的是mashup的组合，所以应该把mashup_embedding放进去
        # mashup的sequence对应的是api的组合，所以应该把api_embedding放进去
        # TODO: 耗时大头...想办法优化下，线程池优化 先简单减少次数吧
        # print("start sim update")
        # self.api_aug_adaptor.similarity_adaptor.update_whole_sim(epoch, mashup_list, mashup_dec_vec, self.mashup_former_sequence, mashup_embeddings)
        # self.mashup_aug_adaptor.similarity_adaptor.update_whole_sim(epoch, api_list, api_dec_vec, self.api_former_sequence, api_embeddings)
        # 使用持久化文件
        if epoch <= self.args.swcs_epoch_threshold:
            t0 = time.time()
            self.api_aug_adaptor.similarity_adaptor.update_whole_sim_using_save(epoch, mashup_list, mashup_dec_vec, self.mashup_former_sequence, mashup_embeddings, mashup_des_sim_file_name)
            self.mashup_aug_adaptor.similarity_adaptor.update_whole_sim_using_save(epoch, api_list, api_dec_vec, self.api_former_sequence, api_embeddings, api_des_sim_file_name)
            t1 = time.time()
            print("single", round((t1 - t0), 1))
        # 合并update在固定间隔轮次时使用
        elif epoch % self.args.swcs_update_space == 0:
            t0 = time.time()
            self.api_aug_adaptor.similarity_adaptor.update_whole_sim_using_save(epoch, mashup_list, mashup_dec_vec, self.mashup_former_sequence, mashup_embeddings, mashup_des_sim_file_name)
            self.mashup_aug_adaptor.similarity_adaptor.update_whole_sim_using_save(epoch, api_list, api_dec_vec, self.api_former_sequence, api_embeddings, api_des_sim_file_name)
            t1 = time.time()
            print("combine", round((t1 - t0), 1))

        # print("start sort")
        # 进行排序
        self.api_aug_adaptor.similarity_adaptor.sort_sim_dict()
        self.mashup_aug_adaptor.similarity_adaptor.sort_sim_dict()
        t2 = time.time()
        # print(round((t2 - t1), 1))

        # print("start sequence augmentation")
        # 进行序列集合的augmentation
        # 两个list对应
        # former_sequence和index对应，所以直接使用api_sample_index_list
        api_aug_sequence_1 = []
        api_aug_sequence_2 = []
        mashup_aug_sequence_1 = []
        mashup_aug_sequence_2 = []
        for i in api_sample_index_list:
            former_seq = self.api_former_sequence[i]
            # 每一个former需要生成pair，也就是aug两次
            temple_seq_1 = self.api_aug_adaptor(former_seq, mashup_list)
            temple_seq_2 = self.api_aug_adaptor(former_seq, mashup_list)
            api_aug_sequence_1.append(temple_seq_1)
            api_aug_sequence_2.append(temple_seq_2)

        for i in mashup_sample_index_list:
            former_seq = self.mashup_former_sequence[i]
            temple_seq_1 = self.mashup_aug_adaptor(former_seq, api_list)
            temple_seq_2 = self.mashup_aug_adaptor(former_seq, api_list)
            mashup_aug_sequence_1.append(temple_seq_1)
            mashup_aug_sequence_2.append(temple_seq_2)

        # print("mean-pooling")
        # 获取这些sequence中对应的service的embeddings，将序号转换成对应的embedding序号
        # 进行mean-pooling处理
        # 方便后续计算感觉应该全改成tensor形式
        # 需要注意的是api list对应的seq中是mashup的序号，mashup反之，不要弄错了
        api_seq_mean_vec_1 = []
        api_seq_mean_vec_2 = []
        mashup_seq_mean_vec_1 = []
        mashup_seq_mean_vec_2 = []
        for api_seq in api_aug_sequence_1:
            # print(api_seq)
            temple_list = []
            for m_index in api_seq:
                # api对应的mashup序列
                temple_list.append(mashup_embeddings[mashup_embed_index_dict[m_index]])
            # 转tensor
            temple_list = torch.stack(temple_list, dim=0)
            api_seq_mean_vec_1.append(temple_list)
        for api_seq in api_aug_sequence_2:
            temple_list = []
            for m_index in api_seq:
                # api对应的mashup序列
                temple_list.append(mashup_embeddings[mashup_embed_index_dict[m_index]])
            temple_list = torch.stack(temple_list, dim=0)
            api_seq_mean_vec_2.append(temple_list)
        for mashup_seq in mashup_aug_sequence_1:
            temple_list = []
            for a_index in mashup_seq:
                # mashup对应的api序列
                temple_list.append(api_embeddings[api_embed_index_dict[a_index]])
            temple_list = torch.stack(temple_list, dim=0)
            mashup_seq_mean_vec_1.append(temple_list)
        for mashup_seq in mashup_aug_sequence_2:
            temple_list = []
            for a_index in mashup_seq:
                # mashup对应的api序列
                temple_list.append(api_embeddings[api_embed_index_dict[a_index]])
            temple_list = torch.stack(temple_list, dim=0)
            mashup_seq_mean_vec_2.append(temple_list)

        # mean-pooling计算
        # print("mean-pooling counting")
        final_mean_api_1 = []
        final_mean_api_2 = []
        final_mean_mashup_1 = []
        final_mean_mashup_2 = []
        # api_avg = nn.AvgPool2d(kernel_size=[api_seq_mean_vec_1[0].shape[0], 1])
        # mashup_avg = nn.AvgPool2d(kernel_size=[mashup_seq_mean_vec_1[0].shape[0], 1])
        for api_vec in api_seq_mean_vec_1:
            api_avg = nn.AvgPool2d(kernel_size=[api_vec.shape[0], 1])
            api_vec = torch.unsqueeze(api_vec, dim=0)
            out = api_avg(api_vec)
            out = torch.squeeze(out)
            final_mean_api_1.append(out)
        for api_vec in api_seq_mean_vec_2:
            api_avg = nn.AvgPool2d(kernel_size=[api_vec.shape[0], 1])
            api_vec = torch.unsqueeze(api_vec, dim=0)
            out = api_avg(api_vec)
            out = torch.squeeze(out)
            final_mean_api_2.append(out)
        for mashup_vec in mashup_seq_mean_vec_1:
            mashup_avg = nn.AvgPool2d(kernel_size=[mashup_vec.shape[0], 1])
            mashup_vec = torch.unsqueeze(mashup_vec, dim=0)
            out = mashup_avg(mashup_vec)
            out = torch.squeeze(out)
            final_mean_mashup_1.append(out)
        for mashup_vec in mashup_seq_mean_vec_2:
            mashup_avg = nn.AvgPool2d(kernel_size=[mashup_vec.shape[0], 1])
            mashup_vec = torch.unsqueeze(mashup_vec, dim=0)
            out = mashup_avg(mashup_vec)
            out = torch.squeeze(out)
            final_mean_mashup_2.append(out)
        final_mean_api_1 = torch.stack(final_mean_api_1, dim=0)
        final_mean_api_2 = torch.stack(final_mean_api_2, dim=0)
        final_mean_mashup_1 = torch.stack(final_mean_mashup_1, dim=0)
        final_mean_mashup_2 = torch.stack(final_mean_mashup_2, dim=0)

        return [final_mean_api_1, final_mean_api_2], [final_mean_mashup_1, final_mean_mashup_2], mashup_embeddings, api_embeddings
