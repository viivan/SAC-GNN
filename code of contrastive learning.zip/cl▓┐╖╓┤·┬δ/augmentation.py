"""
实现各种数据增强方法
crop,mask,importing,changing
reorder对服务推荐来说没意义，不实现了
"""

import math
import torch
import itertools
import copy
import random
import augmentation_similarity as a_s
import util


# crop类，将序列随机裁剪
# 方便轮转调用，进行封装
# c简写
class Crop:

    # 初始化，包括随机的比例
    def __init__(self, eta):
        self.eta = eta

    # 简单随机计算下位置进行裁剪
    def __call__(self, sequence, service_list):
        new_sequence = []
        crop_count = int(self.eta * len(sequence))
        crop_count = max(crop_count, 1)  # 至少一个
        crop_index = random.randint(0, len(sequence) - crop_count)  # 左闭右闭
        for i in range(crop_count):
            index_now = i + crop_index
            new_sequence.append(sequence[index_now])
        return new_sequence


# mask类，简单来说就是序列随机选取，其实对服务推荐来说感觉和随机一样阿
# 方便轮转调用，进行封装
# m简写
class Mask:

    # 初始化，包括随机的比例
    def __init__(self, miu):
        self.miu = miu

    # 简单随机获取
    def __call__(self, sequence, service_list):
        new_sequence = []
        mask_count = int(self.miu * len(sequence))
        mask_count = max(mask_count, 1)  # 至少一个
        rand_list = random.sample([x for x in range(len(sequence))], k=mask_count)
        for rand_now in rand_list:
            new_sequence.append(sequence[rand_now])
        return new_sequence


# changing类，随机获取change位置，找到sim的最大选手进行计算
# 需要用到augmentation_similarity中类
# 方便轮转进行封装
# ch简写
# 由于可能会出现train中不存在的选手，所以需要限定增强结果的范围
class Changing:

    # 初始化，包括change比例，以及sim类的导入
    def __init__(self, alpha, aug_sim):
        self.alpha = alpha
        self.aug_sim = aug_sim

    # 随机获取change选手，计算sim进行替换
    # sim默认是在外部更新的，这边直接进行调用即可
    # 排序方法设置在sim中好了
    def __call__(self, sequence, service_list):
        # key:service value:tuple list [(s1, value)]
        sorted_sim_dict = self.aug_sim.sorted_service_dict
        new_sequence = copy.deepcopy(sequence)
        change_count = int(self.alpha * len(sequence))
        change_count = max(change_count, 1)
        # 随机选取，直接在copy上进行处理
        change_list = random.sample([x for x in range(len(sequence))], k=change_count)
        for i in range(len(sequence)):
            if i in change_list:
                # 使用最相近选手进行处理
                sim_service = util.get_top_sim_service(sorted_sim_dict, sequence[i], top_num=1)
                if sim_service in service_list:
                    new_sequence[i] = sim_service[0]
        return new_sequence


# importing方法，找寻最相近的进行插入增强
# 需要用到augmentation_similarity中类
# 方便轮转进行封装
# im简写
class Importing:

    # 初始化，包括修改的数量和sim类的导入
    # 初始化，包括change比例，以及sim类的导入
    def __init__(self, beta, aug_sim):
        self.beta = beta
        self.aug_sim = aug_sim

    def __call__(self, sequence, service_list):
        # key:service value:tuple list [(s1, value)]
        sorted_sim_dict = self.aug_sim.sorted_service_dict
        new_sequence = []
        import_count = int(self.beta * len(sequence))
        import_count = max(import_count, 1)
        # 随机选取，直接在copy上进行处理
        import_list = random.sample([x for x in range(len(sequence))], k=import_count)
        for i in range(len(sequence)):
            new_sequence.append(sequence[i])
            if i in import_list:
                # 使用最相近选手进行处理
                sim_service = util.get_top_sim_service(sorted_sim_dict, sequence[i], top_num=1)
                if sim_service in service_list:
                    new_sequence.append(sim_service[0])
        return new_sequence


# 轮转方法，有参考
# pair选择增强方式
# 使用itertools进行pair的对应，之后轮转进行augmentation方法的调用
class AugmentationAdaptor:

    def __init__(self, similarity_adaptor, args):
        self.count_now = 0  # 当前序号，到达边界时需要进行求余变换
        self.whole_num = 0  # 增强方法类别形成序列后的总长度
        self.augmentation_methods = []
        self.aug_index_list = []
        self.similarity_adaptor = similarity_adaptor
        self.args = args

    # 方便使用不同的augmentation组合
    # 输入参数为简写，通过缩写进行情况判断
    # 形式如 c,m,ch,im
    def append_aug_method(self, method_list):
        aug_methods = []
        aug_abbreviate_list = str(method_list).split(",")
        for abb in aug_abbreviate_list:
            if abb == "c":
                aug_methods.append(Crop(self.args.aug_crop))
            elif abb == "m":
                aug_methods.append(Mask(self.args.aug_mask))
            elif abb == "ch":
                aug_methods.append(Changing(self.args.aug_changing, self.similarity_adaptor))
            elif abb == "im":
                aug_methods.append(Importing(self.args.aug_importing, self.similarity_adaptor))
        self.augmentation_methods = aug_methods
        self.whole_num = len(self.augmentation_methods)

    # 一定的顺序构造增强方法调用序列
    # 轮转pair匹配
    def create_aug_index_list(self):
        s = []
        for (a1, a2) in itertools.combinations([i for i in range(self.whole_num)], 2):
            s.append(a1)
            s.append(a2)
        self.aug_index_list = s

    # 调用对应的增强方法进行处理
    def __call__(self, sequence, service_list):
        aug_method_now = self.augmentation_methods[self.aug_index_list[self.count_now]]
        self.count_now += 1
        if self.count_now == len(self.aug_index_list):
            self.count_now = 0
        return aug_method_now(sequence, service_list)